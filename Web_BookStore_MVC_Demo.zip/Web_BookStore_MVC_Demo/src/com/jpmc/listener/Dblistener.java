package com.jpmc.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.jpmc.dao.classes.DbConnection;



public class Dblistener implements ServletContextListener {

    
    public Dblistener() {
        // TODO Auto-generated constructor stub
    }

	
    public void contextDestroyed(ServletContextEvent event)  { 
    	
         // TODO Auto-generated method stub
    	
    	System.out.println("Context Destroyed");
    }

	
    public void contextInitialized(ServletContextEvent event)  { 
         // TODO Auto-generated method stub
    	
System.out.println("Context Initialized..");
    	
    	String driverClass= event.getServletContext().getInitParameter("DriverClass");
    	String dbUrl=event.getServletContext().getInitParameter("DBUrl");
    	String username=event.getServletContext().getInitParameter("User");
    	String password=event.getServletContext().getInitParameter("Password");
    	
    	DbConnection.SetConnection(driverClass, dbUrl, username, password);
    }
	
}
