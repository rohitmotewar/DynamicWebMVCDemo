package com.jpmc.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.jpmc.dao.classes.DbConnection;

/**
 * Application Lifecycle Listener implementation class DbListener2
 *
 */
public class DbListener2 implements ServletContextListener {

    /**
     * Default constructor. 
     */
    public DbListener2() {
        // TODO Auto-generated constructor stub
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent event)  { 
         // TODO Auto-generated method stub
    	System.out.println("Context Destroyed");
    }

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent event)  { 
         // TODO Auto-generated method stub
    	
System.out.println("Context Initialized..");
    	
    	String driverClass= event.getServletContext().getInitParameter("DriverClass");
    	String dbUrl=event.getServletContext().getInitParameter("DBUrl");
    	String username=event.getServletContext().getInitParameter("User");
    	String password=event.getServletContext().getInitParameter("Password");
    	
    	DbConnection.SetConnection(driverClass, dbUrl, username, password);
    }
	
}
