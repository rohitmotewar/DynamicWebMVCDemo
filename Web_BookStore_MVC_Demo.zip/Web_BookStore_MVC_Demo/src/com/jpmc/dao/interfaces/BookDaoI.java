package com.jpmc.dao.interfaces;

import java.util.List;

import com.jpmc.beans.Book;

public interface BookDaoI 
{

	public int addBook(String isbn,String title,String author,double price,long stock); // we use int return type whenever we are using execute function which returns in integer.
	public int deleteBook(String isbn);

	public List<Book> getAllBooks(); // Used List here because, will be easy to populate in all web pages and phone/apps.
	public int updateStock(String isbn,long newStock);
		
	
}
