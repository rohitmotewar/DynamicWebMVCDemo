package com.jpmc.dao.interfaces;

import com.jpmc.beans.User;

public interface LoginDaoI 
{
	public User validateUser(User user);
	
	//here we are creating the object of user as we can track the activity of User and see the profile of user.
	
}
