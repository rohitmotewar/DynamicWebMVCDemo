package com.jpmc.dao.interfaces;

import com.jpmc.beans.Customer;

public interface CustomerDaoI 
{

	public Customer getCustomer(String phoneNumber); //To get the cut based phonenumber and print

	

	
	
	
	
}
