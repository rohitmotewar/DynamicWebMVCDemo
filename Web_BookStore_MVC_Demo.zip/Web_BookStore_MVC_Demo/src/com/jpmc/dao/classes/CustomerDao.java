package com.jpmc.dao.classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jpmc.beans.Customer;
import com.jpmc.dao.interfaces.CustomerDaoI;

public class CustomerDao implements CustomerDaoI 
{

	private Connection conn;
	
	public CustomerDao()
	{
		conn=DbConnection.getConnection();
		
	}
	
	@Override
	public Customer getCustomer(String phoneNumber) {
		
		String template="select * from customer where cPhoneNumber=?";
		try
		{
			PreparedStatement pst=conn.prepareStatement(template);
			pst.setString(1, phoneNumber);;
			ResultSet rs=pst.executeQuery();
			
			if(rs.next())
			{
				Customer cust=new Customer(rs.getString("custId"),
				rs.getString("cName"),rs.getString("cPostalAddress"),
				rs.getString("cEmail"),rs.getString("cPhoneNumber"));
				
				return cust;
			}
			return null;
			
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	
	
	
	
}
