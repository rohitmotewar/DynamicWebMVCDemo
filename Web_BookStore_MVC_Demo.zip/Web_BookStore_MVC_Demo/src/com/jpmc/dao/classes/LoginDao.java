package com.jpmc.dao.classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.jpmc.beans.User;
import com.jpmc.dao.interfaces.LoginDaoI;

public class LoginDao implements LoginDaoI
{
	private Connection connection;
	
	
	public LoginDao()
	{
			
	connection=DbConnection.getConnection();
	}
	

	public User validateUser(User user) {
		// TODO Auto-generated method stub
		
		String templates="select * from users where phoneNumber=? and password=?";
		try
		{
			PreparedStatement pst=connection.prepareStatement(templates);
			pst.setString(1, user.getPhoneNumber());
			pst.setString(2, user.getPassword());
			ResultSet rs=pst.executeQuery();
			if(rs.next()) //Means if record is there...
			{
				user.setRole(rs.getString(4));
				return user;
			}
			
			return null; //rs.next= false then user is invalid
		}
		catch(SQLException e)
		{
			e.printStackTrace();
			
		}
		
		return null;
	}


	

	
}
