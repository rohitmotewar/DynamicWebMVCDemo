package com.jpmc.dao.classes;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.jpmc.beans.Book;
import com.jpmc.dao.interfaces.BookDaoI;

public class BookDao implements BookDaoI
{
	private Connection conn;
public BookDao()
{
	conn=DbConnection.getConnection();
	
	
	
}
	
	@Override
	public int addBook(String isbn, String title, String author, double price, long stock) {
		
		try{
			String template ="insert into book values(?,?,?,?,?)";
			PreparedStatement pstmt = conn.prepareStatement(template);
			
			pstmt.setString(1, isbn);  pstmt.setString(2, title);
			pstmt.setString(3, author);pstmt.setDouble(4, price);
			pstmt.setLong(5, stock);
			
			
			return pstmt.executeUpdate();
					
			}catch(SQLException e)
			{
				e.printStackTrace();
			}
			return 0;
		
		
	}

	@Override
	public int deleteBook(String isbn) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Book> getAllBooks() {
		
		
		List<Book> bookList=new ArrayList<>();
		try{
			String query = "select * from Book";
			PreparedStatement pstmt=conn.prepareStatement(query);
			
			/*Statement stmt=connection.createStatement();
			ResultSet rs=stmt.executeQuery(query);*/
			
			ResultSet rs = pstmt.executeQuery();
			while(rs.next())
			{
	Book book=new Book(rs.getString("isbn"),rs.getString("title"),
			rs.getString("author"),rs.getDouble("price"),rs.getLong("stock"));
	
			bookList.add(book);
			}
			return bookList;
				
			
		}catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return null;
		
		
	}

	@Override
	public int updateStock(String isbn, long newStock) {
		// TODO Auto-generated method stub
		return 0;
	}

	
	
	
}
