package com.jpmc.dao.classes;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection 
{

	private static Connection connection;
	
	private DbConnection()
	{
		
	}
	
	public static Connection getConnection()
	{
		return connection;
		
	}
	

	public static void SetConnection(String driverClass,String dbUrl,String username,String password)
	{
		
		try{
			Class.forName(driverClass);
			
			connection=DriverManager.getConnection(dbUrl,username,password);
			//System.out.println("Db Connected");
				if(connection!=null)
				{
					System.out.println("Connected to Oracle DB");
				}
				else
				{
					System.out.println("Failed to connect");
				}
			
			}	
	
		catch(ClassNotFoundException | SQLException e)
		{
			System.out.println(e);
			//e.printStackTrace();
							
		}
		
		
	}
	
}
