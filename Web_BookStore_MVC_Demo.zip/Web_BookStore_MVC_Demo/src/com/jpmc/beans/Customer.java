package com.jpmc.beans;

import java.io.Serializable;

public class Customer  implements Serializable
{
	private String custId;
	private String Name;
	private String address;
	private String email;
	private String phoneNumber;
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Customer(String custId, String name, String address, String email, String phoneNumber) {
		super();
		this.custId = custId;
		Name = name;
		this.address = address;
		this.email = email;
		this.phoneNumber = phoneNumber;
	}
	@Override
	public String toString() {
		return "Customer [custId=" + custId + ", Name=" + Name + ", address=" + address + ", email=" + email
				+ ", phoneNumber=" + phoneNumber + "]";
	}
	public Customer() {
		super();
	}
	
	
	
	
}
