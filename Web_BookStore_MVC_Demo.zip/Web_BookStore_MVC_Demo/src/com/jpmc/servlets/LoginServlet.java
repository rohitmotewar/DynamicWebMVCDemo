package com.jpmc.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jpmc.beans.Book;
import com.jpmc.beans.Customer;
import com.jpmc.beans.User;
import com.jpmc.services.classes.BookService;
import com.jpmc.services.classes.CustomerService;
import com.jpmc.services.classes.LoginService;
import com.jpmc.services.interfaces.BookServiceI;
import com.jpmc.services.interfaces.CustomerServiceI;
import com.jpmc.services.interfaces.LoginServiceI;

public class LoginServlet extends HttpServlet {
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//LoginDaoI logindao=new LoginDao();
		HttpSession session=null;
		
		LoginServiceI loginService=new LoginService();
		
		CustomerServiceI customerService=null;
		BookServiceI bookService=null;
		
		
		//System.out.println(loginService.validateUser(new User("123456789", "admin", "")));
		
		User user=new User(request.getParameter("phonenumber"),request.getParameter("password"),"");
		
		user=loginService.validateUser(user);
		System.out.println("Record avail " +user);
		
		String path="";
		String errorMsg="User not valid";
		
		/* If user is null go to login.jsp with error msg else if role is admin go to adminhome.jsp else if role is customer
		 * get customer from Db based on phone number*/
			
		if(user==null)
		{
			path="login.jsp";
			request.setAttribute("message", errorMsg);
			
		}
		else
		{
			if(user.getRole().equalsIgnoreCase("admin")) path="adminhome.jsp";
				else
				{
					customerService=new CustomerService();
					
					bookService=new BookService();
										
					Customer customer=customerService.getCustomer(user.getPhoneNumber());
					
					
					List<Book> books = bookService.getAllBooks(); // List all the books
					
					session=request.getSession();
					session.setAttribute("customer", customer);
					session.setAttribute("books",books);
					
					path="customerHomeEL.jsp";
								
							
				}
		}
		
		request.getRequestDispatcher(path).forward(request, response);
		
	
			}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//System.out.println("Here");
		
	}

}
