package com.jpmc.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.jpmc.beans.Book;
import com.jpmc.services.classes.BookService;
import com.jpmc.services.interfaces.BookServiceI;


public class CustomerServlet extends HttpServlet {
	

	HttpSession session=null;
	List<Book> books=null;
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	
		//System.out.println("Customer Servlet");
		
		String action=request.getParameter("action");
		String path="";
		
		
		switch(action)
		{
		
		case "add":
				
			String isbn=request.getParameter("isbn");
			HttpSession session = request.getSession();
			System.out.println("ISBN Received-"+isbn);
			
			BookServiceI b=new BookService();
			List<Book> books = b.getAllBooks();
			System.out.println("list:"+books);
			Book book = search(books,isbn);
			
			
			//session=request.getSession();
			
			//books=(List<Book>) session.getAttribute("books");
			
			//Book book=search(books,isbn);
			
			
			List<Book> cart=new ArrayList<>();
			cart=(List<Book>) session.getAttribute("cart");
			
				if(cart==null)
					cart=new ArrayList<>(); //Cart is created when first book added.
				
			cart.add(book);
			
			session.setAttribute("cart",cart);
			
			System.out.println(cart);	
			
			path="customerHomeEL.jsp";
			PrintWriter out=response.getWriter();
			out.print("cart is"+cart);
			
			
					
			/*session=request.getSession();
			
			session.setAttribute("books",books);*/
			
			break;		
		
		/*case "checkout":
			session = request.getSession();
			cart=(List<Book>)session.getAttribute("cart");
			cart.clear();
			session.invalidate();
			request.getRequestDispatcher("login.jsp").forward(request, response);
			break;*/
			
		
			
		case "signout":
			session =request.getSession();
			cart=(List<Book>)session.getAttribute("cart");
			
			cart.clear();
			session.invalidate();
			request.getRequestDispatcher("login.jsp").forward(request, response);

						
			
		}
			

		
		//request.getRequestDispatcher("customerHomeEL.jsp").forward(request,response);
		
		
	}

	
	private Book search(List<Book> books2, String isbn) 
	{
		for(Book book:books2)
		{
			if(book.getIsbn().equals(isbn));
			return book;
					
			
		}
		return null;
		

		
		
		
		
	}
	
	private double calculateBillAmount(List<Book> cart)
	{
		double amount=0;
		for (Book book:cart)
		{
			
		}
		return 0;
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
