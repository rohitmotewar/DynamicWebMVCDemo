package com.jpmc.services.interfaces;

import com.jpmc.beans.User;

public interface LoginServiceI 
{
	public User validateUser(User user);

	
}
