package com.jpmc.services.interfaces;

import java.util.List;

import com.jpmc.beans.Book;

public interface BookServiceI 
{

	public List<Book> getAllBooks();
	
}
