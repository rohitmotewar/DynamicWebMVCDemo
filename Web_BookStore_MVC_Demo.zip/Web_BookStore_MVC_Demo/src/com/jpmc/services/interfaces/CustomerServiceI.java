package com.jpmc.services.interfaces;

import com.jpmc.beans.Customer;

public interface CustomerServiceI 
{

	public Customer getCustomer(String phoneNumber);

	
	
}
