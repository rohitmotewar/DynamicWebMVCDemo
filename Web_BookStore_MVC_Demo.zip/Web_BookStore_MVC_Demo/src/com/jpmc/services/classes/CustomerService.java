package com.jpmc.services.classes;

import com.jpmc.beans.Customer;
import com.jpmc.dao.classes.CustomerDao;
import com.jpmc.dao.interfaces.CustomerDaoI;
import com.jpmc.services.interfaces.CustomerServiceI;

public class CustomerService implements CustomerServiceI
{

	private CustomerDaoI customerDao;

	@Override
	public Customer getCustomer(String phoneNumber) {
	
customerDao=new CustomerDao();
		
		return customerDao.getCustomer(phoneNumber);
		
	
	}

	

		
	
}
