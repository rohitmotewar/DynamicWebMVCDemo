package com.jpmc.services.classes;

import java.util.List;

import com.jpmc.beans.Book;
import com.jpmc.dao.classes.BookDao;
import com.jpmc.dao.interfaces.BookDaoI;
import com.jpmc.services.interfaces.BookServiceI;
import com.sun.org.apache.bcel.internal.generic.RETURN;

public class BookService implements BookServiceI
{
	private BookDaoI bookDao;
	
	@Override
	public List<Book> getAllBooks() {
		bookDao=new BookDao();
		
		return bookDao.getAllBooks();
		
	}

}
